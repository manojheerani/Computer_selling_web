from django.contrib import admin
from django.urls import path
from Myfirstapp import views
urlpatterns = [
    path("", views.index, name="Myfirstapp"),
    path("About", views.About, name="Myfirstapp"),
    path("Services", views.Services, name="Myfirstapp"),
    path("Contact", views.ContactUs, name="Myfirstapp"),
    path("Gallary", views.Gallary, name="Myfirstapp"),


]
