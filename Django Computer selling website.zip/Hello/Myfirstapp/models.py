from django.db import models
# Create your models here.


class Contact(models.Model):
    Fname = models.CharField(max_length=150)
    Lname = models.CharField(max_length=150)
    email = models.EmailField(max_length=100)
    password = models.CharField(max_length=150)
    address = models.CharField(max_length=200)
    comment = models.TextField()
    city = models.CharField(max_length=100)
    province = models.CharField(max_length=50)
    zipcode = models.CharField(max_length=150)

    def __str__(self):
        return self.Fname
