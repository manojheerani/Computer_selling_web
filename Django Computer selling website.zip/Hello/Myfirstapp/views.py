from django.shortcuts import render
from Myfirstapp.models import Contact
from django.contrib import messages
# Create your views here.


def index(request):
    messages.success(request, message="This is Test Message")
    return render(request, 'Index.html')


def About(request):
    return render(request, 'About.html')


def Services(request):
    return render(request, 'Services.html')


def ContactUs(request):
    if request.method == "POST":
        Fname = request.POST.get("Fname")
        Lname = request.POST.get("Lname")
        email = request.POST.get("email")
        password = request.POST.get("password")
        address = request.POST.get("address")
        comment = request.POST.get("comment")
        city = request.POST.get("city")
        province = request.POST.get("province")
        zipcode = request.POST.get("zipcode")
        contact = Contact(Fname=Fname, Lname=Lname, email=email, password=password,
                          address=address, comment=comment, city=city, province=province, zipcode=zipcode)
        contact.save()
        messages.success(request, 'Your message has been sent')
    return render(request, 'Contact.html')


def Gallary(request):
    return render(request, 'Gallary.html')
